blockId = config.getBlockId("RageStone001");
blockMeta = 11;
generationsPerChunk = 5.0;
numberOfBlocks = 40;
minHeight = 1;
maxHeight = 15;
overworldReplacedBlocks = "1, 3, 13";