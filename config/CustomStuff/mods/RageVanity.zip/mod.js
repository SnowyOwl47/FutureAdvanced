mod.addCreativeTab("Vanity", 30173, 0);

id = 25500;
for (i=0; i<38; i++) {
  tag = "RageVanity" + pad(i, 3)
  if ((i != 25)  && (i != 34)) {config.addItemIdProperty(tag + "aID", id);}
  config.addItemIdProperty(tag + "bID", id + 1);
  config.addItemIdProperty(tag + "cID", id + 2);
  if ((i != 35) && (i != 32)) {config.addItemIdProperty(tag + "dID", id + 3);}
  if ((i != 25)  && (i != 34)) {mod.addItem(tag + "a.js", "armor");}
  mod.addItem(tag + "b.js", "armor");
  mod.addItem(tag + "c.js", "armor");
  if ((i != 35) && (i != 32)) {mod.addItem(tag + "d.js", "armor");}
  id = id + 4;
}

// functions
function pad (str, max) 
{
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}