name = "RageVanity035d";
id = config.getItemId(name + "ID");
displayName[0] = "Wizard Boots";
armorTexture = "RageVanity035a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";