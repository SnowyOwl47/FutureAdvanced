name = "RageVanity023d";
id = config.getItemId(name + "ID");
displayName[0] = "Shell Boots";
armorTexture = "RageVanity023a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";