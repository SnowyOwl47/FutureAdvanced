name = "RageVanity001a";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Gold Helmet";
armorTexture = "RageVanity001a.png";
textureFile[0] = "/gold_helmet.png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";