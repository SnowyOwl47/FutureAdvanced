name = "RageVanity021c";
id = config.getItemId(name + "ID");
displayName[0] = "Red Hood Leggings";
armorTexture = "RageVanity021b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";