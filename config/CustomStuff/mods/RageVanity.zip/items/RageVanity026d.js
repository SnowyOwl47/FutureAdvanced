name = "RageVanity026d";
id = config.getItemId(name + "ID");
displayName[0] = "Thor Boots";
armorTexture = "RageVanity026a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";