name = "RageVanity015a";
id = config.getItemId(name + "ID");
displayName[0] = "Hulk Helmet";
armorTexture = "RageVanity015a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";