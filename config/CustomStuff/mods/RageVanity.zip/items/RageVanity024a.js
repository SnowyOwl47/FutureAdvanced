name = "RageVanity024a";
id = config.getItemId(name + "ID");
displayName[0] = "Spiderman Helmet";
armorTexture = "RageVanity024a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";