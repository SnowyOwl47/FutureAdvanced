name = "RageVanity002c";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Diamond Leggings";
armorTexture = "RageVanity002b.png";
textureFile[0] = "/diamond_leggings.png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";