name = "RageVanity002d";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Diamond Boots";
armorTexture = "RageVanity002a.png";
textureFile[0] = "/diamond_boots.png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";