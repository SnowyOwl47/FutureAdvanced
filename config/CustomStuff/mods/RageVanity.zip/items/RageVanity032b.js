name = "RageVanity032b";
id = config.getItemId(name + "ID");
displayName[0] = "Ninja Chest";
armorTexture = "RageVanity032a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";