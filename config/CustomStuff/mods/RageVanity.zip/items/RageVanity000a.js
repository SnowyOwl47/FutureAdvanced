name = "RageVanity000a";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Iron Helmet";
armorTexture = "RageVanity000a.png";
textureFile[0] = "/iron_helmet.png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";