name = "RageVanity031a";
id = config.getItemId(name + "ID");
displayName[0] = "Commissar Helmet";
armorTexture = "RageVanity031a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";