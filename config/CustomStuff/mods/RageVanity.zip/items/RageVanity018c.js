name = "RageVanity018c";
id = config.getItemId(name + "ID");
displayName[0] = "Ironman 2 Leggings";
armorTexture = "RageVanity018b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";