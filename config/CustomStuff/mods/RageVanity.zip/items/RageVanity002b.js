name = "RageVanity002b";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Diamond Chest";
armorTexture = "RageVanity002a.png";
textureFile[0] = "/diamond_chestplate.png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";