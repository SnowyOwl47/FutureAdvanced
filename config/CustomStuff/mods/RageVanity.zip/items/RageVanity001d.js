name = "RageVanity001d";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Gold Boots";
armorTexture = "RageVanity001a.png";
textureFile[0] = "/gold_boots.png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";