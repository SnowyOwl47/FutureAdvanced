name = "RageVanity020b";
id = config.getItemId(name + "ID");
displayName[0] = "Nightwing Chest";
armorTexture = "RageVanity020a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";