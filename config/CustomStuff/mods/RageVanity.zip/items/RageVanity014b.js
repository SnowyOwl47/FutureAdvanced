name = "RageVanity014b";
id = config.getItemId(name + "ID");
displayName[0] = "Green Lantern Chest";
armorTexture = "RageVanity014a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";