name = "RageVanity003c";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Chainmail Leggings";
armorTexture = "RageVanity003b.png";
textureFile[0] = "/chainmail_leggings.png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";