name = "RageVanity037a";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Emerald Helmet";
armorTexture = "RageVanity037a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";