name = "RageVanity028c";
id = config.getItemId(name + "ID");
displayName[0] = "Wolverine Leggings";
armorTexture = "RageVanity028b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";