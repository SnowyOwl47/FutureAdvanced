name = "RageVanity018d";
id = config.getItemId(name + "ID");
displayName[0] = "Ironman 2 Boots";
armorTexture = "RageVanity018a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";