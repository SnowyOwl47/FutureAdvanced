name = "RageVanity008a";
id = config.getItemId(name + "ID");
displayName[0] = "Black Panther Helmet";
armorTexture = "RageVanity008a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";