name = "RageVanity003b";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Chainmail Chest";
armorTexture = "RageVanity003a.png";
textureFile[0] = "/chainmail_chestplate.png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";