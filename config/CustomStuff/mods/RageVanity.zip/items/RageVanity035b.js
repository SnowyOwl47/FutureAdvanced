name = "RageVanity035b";
id = config.getItemId(name + "ID");
displayName[0] = "Wizard Chest";
armorTexture = "RageVanity035a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";