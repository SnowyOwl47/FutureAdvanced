name = "RageVanity008c";
id = config.getItemId(name + "ID");
displayName[0] = "Black Panther Leggings";
armorTexture = "RageVanity008b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";