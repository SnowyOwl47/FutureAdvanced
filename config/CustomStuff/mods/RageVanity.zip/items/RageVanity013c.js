name = "RageVanity013c";
id = config.getItemId(name + "ID");
displayName[0] = "Green Arrow Leggings";
armorTexture = "RageVanity013b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";