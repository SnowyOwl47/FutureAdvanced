name = "RageVanity004b";
id = config.getItemId(name + "ID");
displayName[0] = "Ant-Man Chest";
armorTexture = "RageVanity004a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";