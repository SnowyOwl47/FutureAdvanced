name = "RageVanity003d";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Chainmail Boots";
armorTexture = "RageVanity003a.png";
textureFile[0] = "/chainmail_boots.png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";