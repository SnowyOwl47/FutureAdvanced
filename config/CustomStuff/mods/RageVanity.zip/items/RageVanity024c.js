name = "RageVanity024c";
id = config.getItemId(name + "ID");
displayName[0] = "Spiderman Leggings";
armorTexture = "RageVanity024b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";