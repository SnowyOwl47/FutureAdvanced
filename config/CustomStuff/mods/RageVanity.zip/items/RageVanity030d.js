name = "RageVanity030d";
id = config.getItemId(name + "ID");
displayName[0] = "Assassin Boots";
armorTexture = "RageVanity030a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";