name = "RageVanity002a";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Diamond Helmet";
armorTexture = "RageVanity002a.png";
textureFile[0] = "/diamond_helmet.png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";