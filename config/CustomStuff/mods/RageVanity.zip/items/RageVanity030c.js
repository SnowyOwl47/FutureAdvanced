name = "RageVanity030c";
id = config.getItemId(name + "ID");
displayName[0] = "Assassin Leggings";
armorTexture = "RageVanity030b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";