name = "RageVanity012b";
id = config.getItemId(name + "ID");
displayName[0] = "Flash Chest";
armorTexture = "RageVanity012a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";