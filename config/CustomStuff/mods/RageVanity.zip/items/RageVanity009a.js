name = "RageVanity009a";
id = config.getItemId(name + "ID");
displayName[0] = "Captain America Helmet";
armorTexture = "RageVanity009a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";