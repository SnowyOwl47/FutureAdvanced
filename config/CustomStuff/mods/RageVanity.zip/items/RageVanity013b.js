name = "RageVanity013b";
id = config.getItemId(name + "ID");
displayName[0] = "Green Arrow Chest";
armorTexture = "RageVanity013a.png";
textureFile[0] = name + ".png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";