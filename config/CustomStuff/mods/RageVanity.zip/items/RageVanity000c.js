name = "RageVanity000c";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Iron Leggings";
armorTexture = "RageVanity000b.png";
textureFile[0] = "/iron_leggings.png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";