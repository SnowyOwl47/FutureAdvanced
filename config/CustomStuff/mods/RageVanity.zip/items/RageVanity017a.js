name = "RageVanity017a";
id = config.getItemId(name + "ID");
displayName[0] = "Ironman Helmet";
armorTexture = "RageVanity017a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";