name = "RageVanity027c";
id = config.getItemId(name + "ID");
displayName[0] = "Wasp Leggings";
armorTexture = "RageVanity027b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";