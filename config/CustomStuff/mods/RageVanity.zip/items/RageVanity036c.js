name = "RageVanity036c";
id = config.getItemId(name + "ID");
displayName[0] = "x407 Leggings";
armorTexture = "RageVanity036b.png";
textureFile[0] = name + ".png";
armorType = "legs";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";