name = "RageVanity000d";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Iron Boots";
armorTexture = "RageVanity000a.png";
textureFile[0] = "/iron_boots.png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";