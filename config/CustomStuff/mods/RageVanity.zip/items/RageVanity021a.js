name = "RageVanity021a";
id = config.getItemId(name + "ID");
displayName[0] = "Red Hood Helmet";
armorTexture = "RageVanity021a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";