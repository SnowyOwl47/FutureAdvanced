name = "RageVanity019d";
id = config.getItemId(name + "ID");
displayName[0] = "Martian Boots";
armorTexture = "RageVanity019a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";