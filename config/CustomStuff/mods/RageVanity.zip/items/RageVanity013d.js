name = "RageVanity013d";
id = config.getItemId(name + "ID");
displayName[0] = "Green Arrow Boots";
armorTexture = "RageVanity013a.png";
textureFile[0] = name + ".png";
armorType = "boots";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";