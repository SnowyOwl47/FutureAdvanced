name = "RageVanity000b";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Iron Chest";
armorTexture = "RageVanity000a.png";
textureFile[0] = "/iron_chestplate.png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";