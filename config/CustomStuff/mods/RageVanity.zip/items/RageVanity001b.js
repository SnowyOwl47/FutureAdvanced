name = "RageVanity001b";
id = config.getItemId(name + "ID");
displayName[0] = "Decorated Gold Chest";
armorTexture = "RageVanity001a.png";
textureFile[0] = "/gold_chestplate.png";
armorType = "plate";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";