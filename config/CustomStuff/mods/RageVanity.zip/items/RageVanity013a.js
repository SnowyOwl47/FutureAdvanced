name = "RageVanity013a";
id = config.getItemId(name + "ID");
displayName[0] = "Green Arrow Helmet";
armorTexture = "RageVanity013a.png";
textureFile[0] = name + ".png";
armorType = "helmet";

damageReduction = 0;
repairable = false;
addToCreative[0] = true;
creativeTab = "Vanity";