tag = "014";
meta = 14;

name = "RageSeed" + tag;
id = config.getItemId(name + "ID");
maxStack = 64;
creativeTab = "seeds";
var color = new Array("White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Dark Grey", "Light Grey", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black");

displayName[0] = color[meta] + " Flower";
textureFile[0] = "RageSeed" + tag + ".png";
addToCreative[0] = true;
onUse[0] = "if(side == 1 && (world.getBlockId(position) == 2 || world.getBlockId(position) == 3 || world.getBlockId(position) == 60)){position.y++;if(world.getBlockId(position) == 0){position.y--;player.placeBlock(position, side, config.getBlockId('RageCrop000ID'), " + meta.toString() + ", false);player.swingItem();if(player.isInCreative() == false){player.removeFromSlot(player.getCurrentSlot(), 1);}}}";
