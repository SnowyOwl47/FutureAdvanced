tag = "000";
//tickrate = 20;

name = "RageCrop" + tag;
id = config.getBlockId(name + "ID");
material = "plants";
stepSound = "grass";
var color = new Array("White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Dark Grey", "Light Grey", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black");

for (i=0; i<16; i++)
{
  displayName[i] = color[i];
  hardness[i] = 0;
  opacity[i] = 0;
  drop[i] = config.getItemId("RageSeed" + pad(i, 3) + "ID") + " 1";
  hasCollision[i] = false;
  addToCreative[i] = false;
  canSilkHarvest[i] = false;
  tex = name + "abcdefghijklmnop"[i];
  textureFileYP[i] = tex;
  textureFileYN[i] = tex;
  onNeighborChange[i] = "position.y--;if(world.getBlockId(position) != 3 && world.getBlockId(position) != 2 && world.getBlockId(position) != 60){position.y++;world.harvestBlock(position);};";
  //onUpdate[0] = "if(Math.floor(Math.random()*10) < 2){world.setBlockId(position, world.getBlockId(position) + 1);}";
}

// functions
function pad (str, max) 
{
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}