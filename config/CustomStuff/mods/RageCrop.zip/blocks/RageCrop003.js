tag = "003";

name = "RageCrop" + tag;
id = config.getBlockId(name + "ID");
material = "plants";
stepSound = "grass";
var color = new Array("White", "Orange", "Magenta", "Light Blue", "Lime", "Pink", "Dark Grey", "Light Grey", "Cyan", "Purple", "Blue", "Brown", "Green", "Black");

displayName[0] = "White Roses";
displayName[1] = "Orange Wild Poppies";
displayName[2] = "Magenta Wildflowers";
displayName[3] = "Blue Chrysanthemus";
displayName[4] = "Shrub";
displayName[5] = "Pink Dasies";
displayName[6] = "Grey Peonies";
displayName[7] = "Wild Parsley Blooms";
displayName[8] = "Cyan Wildflowers";
displayName[9] = "Purple Violets";
displayName[10] = "Blue Hydrangeas";
displayName[11] = "Dying Shrub";
displayName[12] = "Green Shrug";
displayName[13] = "Black Roses";

for (i=0; i<14; i++)
{
  hardness[i] = 0;
  opacity[i] = 0;
  hasCollision[i] = false;
  addToCreative[i] = true;
  textureFileYN[i] = name + "abcdefghijklmnop"[i] + ".png";
}
