if (Math.floor(Math.random()*10) < 2)
{
  //world.setBlockId(position, world.getBlockId(position) + 1);
}