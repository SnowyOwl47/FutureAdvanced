id = 26800;
for (i=0; i<16; i++)
{
  name = "RageSeed" + pad(i, 3);
  config.addItemIdProperty(name + "ID", id + i);
  mod.addItem(name + ".js", "normal");
}

id = 830;
for (i=0; i<4; i++)
{
  name = "RageCrop" + pad(i, 3);
  config.addBlockIdProperty(name + "ID", id + i);
  mod.addBlock(name + ".js", "wheat");
}

// functions
function pad (str, max) 
{
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}