tag = "002";

name = "RageStone" + tag;
id = config.getBlockId(name + "ID");
material = "rock"
stepSound = "stone";
creativeTab = "buildingBlocks";

displayName[0] = "Granite Cobble";
displayName[1] = "Basalt Cobble";
displayName[2] = "Marble Cobble";
displayName[3] = "Limestone Cobble";
displayName[4] = "Shale Cobble";
displayName[5] = "Sandstone Cobble";
displayName[6] = "Pumice Cobble";
displayName[7] = "Slate Cobble";
displayName[8] = "Gneiss Cobble";
displayName[9] = "Peridotite Cobble";
displayName[10] = "Quartz Cobble";
displayName[11] = "Granulite Cobble";
displayName[12] = "Hornfel Cobble";
displayName[13] = "Migmatite Cobble";
displayName[14] = "Schist Cobble";
displayName[15] = "Onyx Cobble";

for(var i=0; i<16; i++) {
   hardness[i] = 1;
   resistance[i] = 50;
   toolClass[i] = "pickaxe";
   harvestLevel[i] = 1;
   tex = name + "abcdefghijklmnop"[i] + ".png"
   textureFileXP[i] = tex;
   textureFileXN[i] = tex;
   textureFileYP[i] = tex;
   textureFileYN[i] = tex;
   textureFileZP[i] = tex;
   textureFileZN[i] = tex;
   addToCreative[i] = true;
}