tag = "000";

name = "RageStone" + tag;
id = config.getBlockId(name + "ID");
material = "rock"
stepSound = "stone";
creativeTab = "buildingBlocks";

displayName[0] = "Granite";
displayName[1] = "Basalt";
displayName[2] = "Marble";
displayName[3] = "Limestone";
displayName[4] = "Shale";
displayName[5] = "Sandstone";
displayName[6] = "Pumice";
displayName[7] = "Slate";
displayName[8] = "Gneiss";
displayName[9] = "Peridotite";
displayName[10] = "Quartz";
displayName[11] = "Granulite";
displayName[12] = "Hornfel";
displayName[13] = "Migmatite";
displayName[14] = "Schist";
displayName[15] = "Onyx";

for(var i=0; i<16; i++) {
   hardness[i] = 1;
   resistance[i] = 50;
   toolClass[i] = "pickaxe";
   harvestLevel[i] = 1;
   drop[i] = config.getBlockId("RageStone002ID") + ":" + i;
   canSilkHarvest[i] = true;
   tex = name + "abcdefghijklmnop"[i] + ".png"
   textureFileXP[i] = tex;
   textureFileXN[i] = tex;
   textureFileYP[i] = tex;
   textureFileYN[i] = tex;
   textureFileZP[i] = tex;
   textureFileZN[i] = tex;
   addToCreative[i] = true;
}