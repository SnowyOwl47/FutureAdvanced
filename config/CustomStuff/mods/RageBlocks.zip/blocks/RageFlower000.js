tag = "000";

name = "RageFlower" + tag;
id = config.getBlockId(name + "ID");
material = "plants";
stepSound = "grass";
var color = new Array("White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Dark Grey", "Light Grey", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black");

for (i=0; i<16; i++)
{
  displayName[i] = color[i] + "Moon Flower";
  hardness[i] = 0;
  opacity[i] = 0;
  drop[i] = config.getBlockId(name + "ID") + ":" + i.toString() + " 1";
  hasCollision[i] = false;
  addToCreative[i] = true;
  textureFileYN[i] = name + "abcdefghijklmnop"[i] + ".png";
}