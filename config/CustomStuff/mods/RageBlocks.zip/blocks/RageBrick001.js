tag = "001";
name = "RageBrick" + tag;
id = config.getBlockId(name + "ID");
material = "rock"
stepSound = "stone";
creativeTab = "buildingBlocks";

displayName[0] = "Obsidian Bricks";
displayName[1] = "Nether Quartz Bricks";
displayName[2] = "Glowstone Bricks";
displayName[3] = "Redstone Bricks";
displayName[4] = "Lapis Lazuli Bricks";
displayName[5] = "Emerald Bricks";
for(var i=0; i<6; i++) {
   hardness[i] = 1;
   resistance[i] = 50;
   toolClass[i] = "pickaxe";
   harvestLevel[i] = 1;
   canSilkHarvest[i] = true;
   tex = name + "abcdefghijklmnop"[i] + ".png"
   textureFileXP[i] = tex;
   textureFileXN[i] = tex;
   textureFileYP[i] = tex;
   textureFileYN[i] = tex;
   textureFileZP[i] = tex;
   textureFileZN[i] = tex;
   addToCreative[i] = true;
}