tag = "003";

name = "RageStone" + tag;
id = config.getBlockId(name + "ID");
material = "rock"
stepSound = "stone";
creativeTab = "buildingBlocks";

displayName[0] = "Granite Bricks";
displayName[1] = "Basalt Bricks";
displayName[2] = "Marble Bricks";
displayName[3] = "Limestone Bricks";
displayName[4] = "Shale Bricks";
displayName[5] = "Sandstone Bricks";
displayName[6] = "Pumice Bricks";
displayName[7] = "Slate Bricks";
displayName[8] = "Gneiss Bricks";
displayName[9] = "Peridotite Bricks";
displayName[10] = "Quartz Bricks";
displayName[11] = "Granulite Bricks";
displayName[12] = "Hornfel Bricks";
displayName[13] = "Migmatite Bricks";
displayName[14] = "Schist Bricks";
displayName[15] = "Onyx Bricks";

for(var i=0; i<16; i++) {
   hardness[i] = 1;
   resistance[i] = 50;
   toolClass[i] = "pickaxe";
   harvestLevel[i] = 1;
   tex = name + "abcdefghijklmnop"[i] + ".png"
   textureFileXP[i] = tex;
   textureFileXN[i] = tex;
   textureFileYP[i] = tex;
   textureFileYN[i] = tex;
   textureFileZP[i] = tex;
   textureFileZN[i] = tex;
   addToCreative[i] = true;
}