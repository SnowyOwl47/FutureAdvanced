tag = "007";
Idx = 7;

name = "RageVine" + tag;
id = config.getBlockId(name + "ID");
material = "plants";
stepSound = "grass";
creativeTab = "buildingBlocks";
var color = new Array("White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Dark Grey", "Light Grey", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black");

displayName[0] = color[Idx] + " Flowering Vines";
hardness[0] = 1;
resistance[0] = 1;
toolClass[0] = "sheers";
harvestLevel[0] = 1;
tex = name + ".png";
textureFileXP[0] = tex;
textureFileXN[0] = tex;
textureFileYP[0] = tex;
textureFileYN[0] = tex;
textureFileZP[0] = tex;
textureFileZN[0] = tex;
addToCreative[0] = true;