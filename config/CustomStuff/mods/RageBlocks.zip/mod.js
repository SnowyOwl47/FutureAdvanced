config.addBlockIdProperty("RageStone001ID", 3150);
config.addBlockIdProperty("RageBrick000ID", 3151);
config.addBlockIdProperty("RagePlank000ID", 3152);
config.addBlockIdProperty("RagePane000ID", 3153);
mod.addBlock("RageStone001.js", "normal");
mod.addBlock("RageBrick000.js", "normal");
mod.addBlock("RagePlank000.js", "normal");
mod.addBlock("RagePane000.js", "pane");

// mod replacement stuff
// geostrata misc brick, stone, cobble, brick
config.addBlockIdProperty("RageBrick001ID", 1473);
config.addBlockIdProperty("RageStone000ID", 1476);
config.addBlockIdProperty("RageStone002ID", 1475);
config.addBlockIdProperty("RageStone003ID", 1474);
mod.addBlock("RageBrick001.js", "normal");
mod.addBlock("RageStone000.js", "normal");
mod.addBlock("RageStone002.js", "normal");
mod.addBlock("RageStone003.js", "normal");
// pams
config.addBlockIdProperty("RageFlower000ID", 595);
mod.addBlock("RageFlower000.js", "crossTexture");

// lets do loop stuff here, things that loop 0-15 for sub ID
// some quick id var
geoCobble = config.getBlockId("RageStone002ID");
geoStone = config.getBlockId("RageStone000ID");
geoBrick = config.getBlockId("RageStone003ID");
for(i=0; i<16; i++)
{
   //geo cobble to cobble
   mod.addShapelessRecipe(4, "" + geoCobble + ":" + i);
   //geo stone to brick
   tmpStone = "" + geoStone + ":" + i
   mod.addRecipe("" + geoBrick + ":" + i, 2, 2, tmpStone, tmpStone, tmpStone, tmpStone);
   // lets add geo stuff to ore dictionary
   mod.addToOreDictionary("cobblestone", geoCobble, i);
   mod.addToOreDictionary("stone", geoStone, i);
   // and geo cobble to geo stone in furnace
   mod.addSmeltingRecipe("" + geoStone + ":" + i, "" + geoCobble + ":" + i);
   // pam vines
   name = "RageVine" + pad(i, 3);
   config.addBlockIdProperty(name + "ID", 3100 + i);
   mod.addBlock(name + ".js", "ladder");
}

//add our world gens
config.addBooleanProperty("Enable", "worldgen", true);
if(config.getBoolean("Enable", "worldgen"))
{
  for(i=0; i<16; i++)
  {
     mod.addWorldGen("RageGen" + pad(i, 3) + ".js", "ore");
  }
}

// functions
function pad (str, max) 
{
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}