tag = "006";
maxStack = 64;
displayName[0] = "Apple sauce";

name = "RageFood" + tag;
id = config.getItemId(name + "ID");
full3d = false;
creativeTab = "food";

textureFile[0] = name + ".png";
addToCreative[0] = true;
alwaysEdible[0] = false;
hunger[0] = 2;
saturation[0] = 2;