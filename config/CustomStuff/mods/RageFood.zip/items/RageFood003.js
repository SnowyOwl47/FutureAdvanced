tag = "003";
maxStack = 64;
displayName[0] = "Dough";

name = "RageFood" + tag;
id = config.getItemId(name + "ID");
full3d = false;
creativeTab = "food";

textureFile[0] = name + ".png";
addToCreative[0] = true;
alwaysEdible[0] = false;
hunger[0] = 1;
saturation[0] = 1;