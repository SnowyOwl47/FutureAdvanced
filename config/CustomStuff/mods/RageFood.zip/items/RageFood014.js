tag = "014";
maxStack = 64;
displayName[0] = "Raspberry Pie";

name = "RageFood" + tag;
id = config.getItemId(name + "ID");
full3d = false;
creativeTab = "food";

textureFile[0] = name + ".png";
addToCreative[0] = true;
alwaysEdible[0] = false;
hunger[0] = 8;
saturation[0] = 8;