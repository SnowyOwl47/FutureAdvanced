id = 27500;
for (i=0; i<8; i++)
{
  tag = "RageFood" + pad(i, 3);
  config.addItemIdProperty(tag + "ID", id + i);
  mod.addItem(tag + ".js", "food");
}

// aliases
mod.addAlias(260, "Apple");
mod.addAlias(297, "Bread");
mod.addAlias(353, "Sugar");
mod.addAlias(21287, "Mortar1");
mod.addAlias(21286, "Mortar2");
mod.addAliasWithMetadata(21256, 14, "Flour");
mod.addAlias(config.getItemId("RageFood000ID"), "Tortilla");
mod.addAlias(config.getItemId("RageFood002ID"), "Gummy");
mod.addAlias(config.getItemId("RageFood003ID"), "Dough");
mod.addAlias(config.getItemId("RageFood004ID"), "Mutton");
mod.addAlias(config.getItemId("RageFood005ID"), "CookMutton");
mod.addAlias(config.getItemId("RageFood006ID"), "Applesauce");
mod.addAlias(config.getItemId("RageFood007ID"), "Toast");

// remove bad recipes
mod.removeSmeltingRecipe("Flour");

// add new recipes
mod.addSmeltingRecipe("Tortilla 1", "Flour");
mod.addSmeltingRecipe("Gummy 1", "Sugar");
mod.addShapelessRecipe("Dough", "Flour", "Flour");
mod.addSmeltingRecipe("Bread 1", "Dough");
mod.addSmeltingRecipe("CookMutton 1", "Mutton");
mod.addShapelessRecipe("Applesauce", "Mortar1", "Apple", "Apple");
mod.addShapelessRecipe("Applesauce", "Mortar2-", "Apple", "Apple");
mod.addSmeltingRecipe("Toast 1", "Bread");

// mob drops
mod.addMobDrop("Pig", config.getItemId("RageFood004ID"), 0, 1);

// functions
function pad (str, max) 
{
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}